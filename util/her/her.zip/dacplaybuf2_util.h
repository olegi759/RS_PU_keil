/*
 * dac_play_util.h
 *
 *  Created on: 19 февр. 2024 г.
 *      Author: Rafael Boltachev
 *
 *      Библотека для воспроизведения звука на DAC через DMA (устарела)
 */

#ifndef dacplaybuf2_UTIL_H_
#define dacplaybuf2_UTIL_H_



#include "main.h"
#include "def_util.h"
#include "dynbuf_util.h"
#include "dacplay_util.h"


#define DACPLAYBUF2_TIMEOUT	100

typedef struct _dacplaybuf2_data {

	TIM_HandleTypeDef * htim1;
	TIM_HandleTypeDef * htim2;
	uint32_t frequency;
	uint32_t tick;


	dacplay_data_t * dacplay_data1;
	dacplay_data_t * dacplay_data2;
	dynamic_buf_t * dynamic_buf;



} dacplaybuf2_data_t;




void dacplaybuf2_HalfCpltCallback1(dacplaybuf2_data_t * dacplaybuf2_data);
void dacplaybuf2_FullCpltCallback1(dacplaybuf2_data_t * dacplaybuf2_data);
void dacplaybuf2_HalfCpltCallback2(dacplaybuf2_data_t * dacplaybuf2_data);
void dacplaybuf2_FullCpltCallback2(dacplaybuf2_data_t * dacplaybuf2_data);

uint32_t dacplaybuf2_get_frequency(dacplaybuf2_data_t * dacplaybuf2_data);
void dacplaybuf2_set_frequency(dacplaybuf2_data_t * dacplaybuf2_data, uint32_t Frequency);

void dacplaybuf2_set_htim1(dacplaybuf2_data_t * dacplaybuf2_data, TIM_HandleTypeDef * htim);
void dacplaybuf2_set_htim2(dacplaybuf2_data_t * dacplaybuf2_data, TIM_HandleTypeDef * htim)

void dacplaybuf2_set_dacplay_data1(dacplaybuf2_data_t * dacplaybuf2_data, dacplay_data_t * dacplay_data);
void dacplaybuf2_set_dacplay_data2(dacplaybuf2_data_t * dacplaybuf2_data, dacplay_data_t * dacplay_data);

void dacplaybuf2_set_dynamic_buf(dacplaybuf2_data_t * dacplaybuf2_data, dynamic_buf_t * dynamic_buf);
void dacplaybuf2_set_dynamic_buf_size(dacplaybuf2_data_t * dacplaybuf2_data, uint32_t buf_size);




void dacplaybuf2_push(dacplaybuf2_data_t * dacplaybuf2_data, uint16_t * dac_data, uint32_t dac_data_len); //*
void dacplaybuf2_on_read_data(dacplaybuf2_data_t * dacplaybuf2_data, uint16_t * dac_data);

size_t dacplaybuf2_get_free(dacplaybuf2_data_t * dacplaybuf2_data); //*
size_t dacplaybuf2_get_full(dacplaybuf2_data_t * dacplaybuf2_data); //*
void dacplaybuf2_reset(dacplaybuf2_data_t * dacplaybuf2_data); //*


void dacplaybuf2_task(dacplaybuf2_data_t * dacplaybuf2_data); //*



void dacplaybuf2_stop_dma(dacplaybuf2_data_t * dacplaybuf2_data);
BOOL dacplaybuf2_is_dma1_started(dacplaybuf2_data_t * dacplaybuf2_data);
BOOL dacplaybuf2_is_dma2_started(dacplaybuf2_data_t * dacplaybuf2_data);

//NEED
void dacplaybuf2_on_stop_dma(dacplaybuf2_data_t * dacplaybuf2_data);


#endif /* UTIL_dacplaybuf2_UTIL_H_ */

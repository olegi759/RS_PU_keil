/*
 * dacplaybuf2_util.c
 *
 *  Created on: 19 февр. 2024 г.
 *      Author: Rafael Boltachev
 */

#include "dacplaybuf2_util.h"
#include "stm_util.h"


BOOL dacplaybuf2_push(dacplaybuf2_data_t * dacplaybuf2_data, uint16_t * dac_data, uint32_t dac_data_len)
{
	BOOL res;


	res = dynamic_buf_push(dacplaybuf2_data->dynamic_buf, dac_data, dac_data_len * 2);

	if (res && (!dacplay_is_dma_started(dacplaybuf2_data->dacplay_data1 || !dacplay_is_dma_started(dacplaybuf2_data->dacplay_data2) ))) { //дма не завпущено


		if (dynamic_buf_get_data_size(dacplaybuf2_data->dynamic_buf) >  dynamic_buf_get_free_size(dacplaybuf2_data->dynamic_buf)) {
			set_tim_frequency2_and_start(dacplaybuf2_data->htim, dacplaybuf2_data->frequency, BASE_FREQUENCY);
			dacplay_start_dma(dacplaybuf2_data->dacplay_data1);
			dacplay_start_dma(dacplaybuf2_data->dacplay_data2);
		}
	}

	if (!res) {
		ulog("dacplaybuf: FULL"CRLF);
	}

	return res;
}

//вызвать из dacplay_read_data(dacplay_data_t * dacplay_data, uint16_t * dac_data); или из task
void dacplaybuf2_on_read_data(dacplaybuf2_data_t * dacplaybuf2_data, uint16_t * dac_data1, uint16_t * dac_data2)
{
	size_t data_len, i;

	dynamic_buf_pop_line(dacplaybuf2_data->dynamic_buf, dac_data1, DACPLAY_DMA_BUF_SIZE * 2, &data_len);


	if (!data_len) {
		ulog("dacplaybuf: EMPTY"CRLF);

		if (HAL_DiffTick(dacplaybuf2_data->tick) >  DACPLAYBUF2_TIMEOUT) {
			dacplaybuf2_stop_dma(dacplaybuf2_data);
		}
	} else	{
		if (data_len < DACPLAY_DMA_BUF_SIZE * 2) {
			ulog("dacplaybuf: SMALL DATA"CRLF);
			for (i = data_len / 2; i < DACPLAY_DMA_BUF_SIZE; i++) dac_data[i] =  DACPLAY_ZERO_VALUE;
		}
		memcpy(dac_data2, dac_data1, DACPLAY_DMA_BUF_SIZE * 2);
	}

}


//задача
void dacplaybuf2_task(dacplaybuf2_data_t * dacplaybuf2_data)
{
	if (!dacplay_is_dma_started(dacplaybuf2_data->dacplay_data1)) return;
	if (!dacplay_is_dma_started(dacplaybuf2_data->dacplay_data2)) return;

	if ( (dacplaybuf2_data->dacplay_data1->index < 2) && (dacplaybuf2_data->dacplay_data2->index < 2) ){
		dacplaybuf2_on_read_data(dacplaybuf2_data, dacplaybuf2_data->dacplay_data1->dma_buf[dacplaybuf2_data->dacplay_data1->index], dacplaybuf2_data->dacplay_data2->dma_buf[dacplaybuf2_data->dacplay_data2->index]);
		dacplaybuf2_data->dacplay_data1->index = 0xFF;
		dacplaybuf2_data->dacplay_data2->index = 0xFF;
	}
}

void dacplaybuf2_stop_dma(dacplaybuf2_data_t * dacplaybuf2_data)
{
	dacplay_stop_dma(dacplaybuf2_data->dacplay_data1);
	dacplay_stop_dma(dacplaybuf2_data->dacplay_data2);
	dynamic_buf_clear(dacplaybuf2_data->dynamic_buf);
	ulog("dacplaybuf2: STOP"CRLF);
	dacplaybuf2_on_stop_dma(dacplaybuf2_data);
}


void dacplaybuf2_set_htim1(dacplaybuf2_data_t * dacplaybuf2_data, TIM_HandleTypeDef * htim)
{
	dacplaybuf2_data->htim1 = htim;
}

void dacplaybuf2_set_htim2(dacplaybuf2_data_t * dacplaybuf2_data, TIM_HandleTypeDef * htim)
{
	dacplaybuf2_data->htim2 = htim;
}

void dacplaybuf2_set_dacplay_data1(dacplaybuf2_data_t * dacplaybuf2_data, dacplay_data_t * dacplay_data)
{
	dacplaybuf2_data->dacplay_data1 = dacplay_data;
}

void dacplaybuf2_set_dacplay_data2(dacplaybuf2_data_t * dacplaybuf2_data, dacplay_data_t * dacplay_data)
{
	dacplaybuf2_data->dacplay_data2 = dacplay_data;
}

void dacplaybuf2_set_dynamic_buf_size(dacplaybuf2_data_t * dacplaybuf2_data, uint32_t buf_size)
{
	dacplaybuf2_data->dynamic_buf->max_alloc_size =  buf_size;
}

void dacplaybuf2_set_dynamic_buf(dacplaybuf2_data_t * dacplaybuf2_data, dynamic_buf_t * dynamic_buf)
{
	dacplaybuf2_data->dynamic_buf =  dynamic_buf;
}

//Событие по половине DMA
void dacplaybuf2_HalfCpltCallback1(dacplaybuf2_data_t * dacplaybuf2_data)
{

	dacplay_HalfCpltCallback(dacplaybuf2_data->dacplay_data1);
}

//Событие по целой DMA
void dacplaybuf2_FullCpltCallback1(dacplaybuf2_data_t * dacplaybuf2_data)
{
	dacplay_FullCpltCallback(dacplaybuf2_data->dacplay_data1);
}


//Событие по половине DMA
void dacplaybuf2_HalfCpltCallback2(dacplaybuf2_data_t * dacplaybuf2_data)
{

	dacplay_HalfCpltCallback(dacplaybuf2_data->dacplay_data2);
}

//Событие по целой DMA
void dacplaybuf2_FullCpltCallback2(dacplaybuf2_data_t * dacplaybuf2_data)
{
	dacplay_FullCpltCallback(dacplaybuf2_data->dacplay_data2);
}




BOOL dacplaybuf2_is_dma1_started(dacplaybuf2_data_t * dacplaybuf2_data)
{
	return dacplay_is_dma_started(dacplaybuf2_data->dacplay_data);
}

BOOL dacplaybuf2_is_dma2_started(dacplaybuf2_data_t * dacplaybuf2_data)
{
	return dacplay_is_dma_started(dacplaybuf2_data->dacplay_data);
}

//Установка частоты на DAC
void dacplaybuf2_set_frequency(dacplaybuf2_data_t * dacplaybuf2_data, uint32_t Frequency)
{
	dacplaybuf2_data->frequency = Frequency;
}

uint32_t dacplaybuf2_get_frequency(dacplaybuf2_data_t * dacplaybuf2_data)
{
	return dacplaybuf2_data->frequency;
}



size_t dacplaybuf2_get_free(dacplaybuf2_data_t * dacplaybuf2_data)
{
	return dynamic_buf_get_free_size(dacplaybuf2_data->dynamic_buf);
}

size_t dacplaybuf2_get_full(dacplaybuf2_data_t * dacplaybuf2_data)
{
	return dynamic_buf_get_data_size(dacplaybuf2_data->dynamic_buf);
}

void dacplaybuf2_reset(dacplaybuf2_data_t * dacplaybuf2_data)
{
	 dynamic_buf_clear(dacplaybuf2_data->dynamic_buf);
}


